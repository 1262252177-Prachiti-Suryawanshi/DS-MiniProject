import { useEffect, useMemo, useRef, useState } from 'react';
import {
  BarChart3,
  Database,
  GitBranch,
  History,
  ListTree,
  LogOut,
  Redo2,
  RotateCcw,
  Save,
  Search,
  ShieldCheck,
  Trophy,
  Undo2,
  Users,
} from 'lucide-react';
import {
  type Color,
  type GameState,
  type Move,
  type MoveRecord,
  type Piece,
  type PieceType,
  applyMove,
  createInitialState,
  getLegalMoves,
  glyphFor,
  inCheck,
  isGameOver,
  opposite,
  pieceLabel,
  squareName,
  statusLabel,
} from '@/lib/chess';
import {
  BinarySearchTree,
  HashTable,
  MoveLinkedList,
  MovementGraph,
  Queue,
  Stack,
} from '@/lib/data-structures';
import {
  type PlayerStats,
  loadPlayerStats,
  recordResult,
} from '@/lib/player-stats';

const files = 'abcdefgh';
const promotionPieces: PieceType[] = ['q', 'r', 'b', 'n'];
const savedGameKey = 'chess-arena-saved-game';

type PlayerNames = {
  white: string;
  black: string;
};

type EventKind = 'MOVE' | 'CAPTURE' | 'CHECK' | 'PROMOTION' | 'CASTLING' | 'SYSTEM';

type GameEvent = {
  id: number;
  kind: EventKind;
  message: string;
};

type ViewTab = 'history' | 'stats' | 'leaderboard';

function SetupScreen({
  draftNames,
  setDraftNames,
  onStart,
}: {
  draftNames: PlayerNames;
  setDraftNames: (names: PlayerNames) => void;
  onStart: () => void;
}) {
  return (
    <main className="setup-shell">
      <section className="setup-card">
        <div className="brand-mark">
          <div className="brand-knight" aria-hidden="true">♞</div>
          <div>
            <p className="brand-name">CHESS ARENA</p>
            <p className="brand-tagline">Data Structures mini-project</p>
          </div>
        </div>
        <div className="eyebrow">local two-player match</div>
        <h1>Set the players.<br />Start the board.</h1>
        <p className="setup-copy">
          Enter both names before the first move. This offline match keeps the
          board, move record, game events, and player statistics together.
        </p>
        <form
          className="player-form"
          onSubmit={(event) => {
            event.preventDefault();
            onStart();
          }}
        >
          <label>
            <span>White player</span>
            <input
              value={draftNames.white}
              onChange={(event) => setDraftNames({ ...draftNames, white: event.target.value })}
              placeholder="Enter White's name"
              autoFocus
              maxLength={24}
            />
          </label>
          <label>
            <span>Black player</span>
            <input
              value={draftNames.black}
              onChange={(event) => setDraftNames({ ...draftNames, black: event.target.value })}
              placeholder="Enter Black's name"
              maxLength={24}
            />
          </label>
          <button className="start-button" type="submit">
            <Users size={17} />
            Start chess match
          </button>
        </form>
        <div className="setup-footer">
          <span>2 players</span>
          <span>Offline</span>
          <span>All rules active</span>
        </div>
      </section>
      <aside className="setup-brief">
        <div className="eyebrow">what this demonstrates</div>
        <h2>A playable board with visible data structures.</h2>
        <p>
          The board is the 8×8 array. Moves flow through a linked-list history,
          undo uses a stack, game events use a FIFO queue, searching uses hashing,
          movement relationships use a graph, and the leaderboard uses a BST.
        </p>
        <div className="setup-brief-grid">
          <span><strong>01</strong> Move management</span>
          <span><strong>02</strong> Rule validation</span>
          <span><strong>03</strong> Statistics</span>
          <span><strong>04</strong> Search & sort</span>
        </div>
      </aside>
    </main>
  );
}

function App() {
  const [started, setStarted] = useState(false);
  const [draftNames, setDraftNames] = useState<PlayerNames>({ white: '', black: '' });
  const [playerNames, setPlayerNames] = useState<PlayerNames>({ white: 'White', black: 'Black' });
  const [game, setGame] = useState<GameState>(() => createInitialState());
  const [orientation, setOrientation] = useState<Color>('white');
  const [selected, setSelected] = useState<number | null>(null);
  const [promotion, setPromotion] = useState<Move[] | null>(null);
  const [view, setView] = useState<ViewTab>('history');
  const [moveSearch, setMoveSearch] = useState('');
  const [leaderboard, setLeaderboard] = useState<PlayerStats[]>(() => loadPlayerStats());
  const [events, setEvents] = useState<GameEvent[]>([]);
  const [gameSerial, setGameSerial] = useState(0);
  const [, refreshStacks] = useState(0);
  const undoStack = useRef(new Stack<GameState>());
  const redoStack = useRef(new Stack<GameState>());
  const eventQueue = useRef(new Queue<GameEvent>());
  const nextEventId = useRef(1);
  const lastRecordedGame = useRef<number | null>(null);

  const selectedMoves = useMemo(
    () => (selected === null ? [] : getLegalMoves(game, selected)),
    [game, selected],
  );
  const selectedTargets = useMemo(
    () => new Map(selectedMoves.map((move) => [move.to, move])),
    [selectedMoves],
  );
  const checkedKing = inCheck(game.board, game.turn)
    ? game.board.findIndex((piece) => piece?.type === 'k' && piece.color === game.turn)
    : -1;
  const moveList = useMemo(() => {
    const list = new MoveLinkedList<MoveRecord>();
    game.history.forEach((move) => list.append(move));
    return list;
  }, [game.history]);
  const moveSearchIndex = useMemo(() => {
    const table = new HashTable<number[]>();
    game.history.forEach((move, index) => {
      const key = move.san.toLowerCase();
      const matches = table.get(key) ?? [];
      table.set(key, [...matches, index]);
    });
    return table;
  }, [game.history]);
  const movementGraph = useMemo(() => {
    const graph = new MovementGraph();
    if (selected !== null) selectedMoves.forEach((move) => graph.addEdge(selected, move.to));
    return graph;
  }, [selected, selectedMoves]);
  const movePairs = useMemo(() => {
    const pairs: Array<{ number: number; white?: string; black?: string; current?: boolean }> = [];
    moveList.forEach((move, index) => {
      const number = Math.floor(index / 2) + 1;
      let row = pairs[pairs.length - 1];
      if (index % 2 === 0 || !row || row.number !== number) {
        row = { number };
        pairs.push(row);
      }
      if (move.piece.color === 'white') row.white = move.san;
      else row.black = move.san;
      row.current = index === game.history.length - 1;
    });
    return pairs;
  }, [game.history.length, moveList]);
  const displayedMoveIndexes = useMemo(() => {
    const query = moveSearch.trim().toLowerCase();
    if (!query) return game.history.map((_, index) => index);
    const exactMatches = new Set([
      ...(moveSearchIndex.get(query) ?? []),
    ]);
    return moveList.toArray()
      .map((move, index) => ({ move, index }))
      .filter(({ move, index }) => move.san.toLowerCase().includes(query) || exactMatches.has(index))
      .map(({ index }) => index);
  }, [game.history, moveList, moveSearch, moveSearchIndex]);
  const capturedPieces = useMemo(
    () => game.history.flatMap((move) => (move.captured ? [move.captured] : [])),
    [game.history],
  );
  const checkCount = game.history.filter((move) => move.san.endsWith('+') || move.san.endsWith('#')).length;
  const currentPlayer = playerNames[game.turn];
  const winnerColor = game.status === 'checkmate' ? opposite(game.turn) : null;
  const statusHeading = game.status === 'checkmate'
    ? `${playerNames[winnerColor!]} wins by checkmate`
    : game.status === 'playing' && inCheck(game.board, game.turn)
      ? `Check — ${currentPlayer}'s move`
      : game.status === 'playing'
        ? `${currentPlayer}'s move`
        : statusLabel(game.status, game.turn);
  const statusCopy = game.status === 'playing'
    ? inCheck(game.board, game.turn)
      ? 'The king is under attack. Find a legal answer to the threat.'
      : 'Click a piece, then choose one of the highlighted legal squares.'
    : game.status === 'checkmate'
      ? 'The king has no legal escape. This match is complete.'
      : 'The position reached a draw under the rules of chess.';
  const capturedByColor = (color: Color) => capturedPieces.filter((piece) => piece.color === color);
  const leaderboardTree = useMemo(() => {
    const tree = new BinarySearchTree<PlayerStats>();
    leaderboard.forEach((player) => {
      tree.insert(player.wins * 1000 + player.draws * 10 + player.games, player);
    });
    return tree.inorder().reverse().map((entry) => entry.value);
  }, [leaderboard]);

  useEffect(() => {
    if (!started || !isGameOver(game.status) || lastRecordedGame.current === gameSerial) return;
    const winner = game.status === 'checkmate'
      ? game.turn === 'white' ? 'black' : 'white'
      : 'draw';
    const next = recordResult(leaderboard, playerNames.white, playerNames.black, winner);
    setLeaderboard(next);
    lastRecordedGame.current = gameSerial;
  }, [game.status, gameSerial, leaderboard, playerNames, started]);

  const pushEvent = (kind: EventKind, message: string) => {
    eventQueue.current.enqueue({ id: nextEventId.current, kind, message });
    nextEventId.current += 1;
    const processed: GameEvent[] = [];
    eventQueue.current.drain((event) => processed.push(event));
    setEvents((previous) => [...processed, ...previous].slice(0, 8));
  };

  const commit = (move: Move) => {
    const next = applyMove(game, move);
    if (next === game) return;
    undoStack.current.push(game);
    redoStack.current.clear();
    refreshStacks((value) => value + 1);
    setGame(next);
    setSelected(null);
    setPromotion(null);
    pushEvent('MOVE', `${playerNames[move.piece.color]} played ${next.lastMove?.san ?? squareName(move.to)}.`);
    if (move.captured || move.enPassant) pushEvent('CAPTURE', `${playerNames[move.piece.color]} captured a piece.`);
    if (move.castle) pushEvent('CASTLING', `${playerNames[move.piece.color]} castled.`);
    if (move.promotion) pushEvent('PROMOTION', `${playerNames[move.piece.color]} promoted a pawn.`);
    if (inCheck(next.board, next.turn)) pushEvent('CHECK', `${playerNames[next.turn]} is in check.`);
  };

  const handleSquare = (square: number) => {
    if (isGameOver(game.status) || promotion) return;
    const piece = game.board[square];
    if (selected !== null) {
      const candidates = selectedMoves.filter((move) => move.to === square);
      if (candidates.length) {
        if (candidates.some((move) => move.promotion)) setPromotion(candidates);
        else commit(candidates[0]);
        return;
      }
    }
    if (piece?.color === game.turn) setSelected(square);
    else setSelected(null);
  };

  const resetMatch = () => {
    undoStack.current.clear();
    redoStack.current.clear();
    refreshStacks((value) => value + 1);
    setGame(createInitialState());
    setSelected(null);
    setPromotion(null);
    setMoveSearch('');
    setView('history');
    setEvents([]);
    setGameSerial((value) => value + 1);
    lastRecordedGame.current = null;
  };

  const undo = () => {
    const previous = undoStack.current.pop();
    if (!previous) return;
    redoStack.current.push(game);
    refreshStacks((value) => value + 1);
    setGame(previous);
    setSelected(null);
    setPromotion(null);
  };

  const redo = () => {
    const next = redoStack.current.pop();
    if (!next) return;
    undoStack.current.push(game);
    refreshStacks((value) => value + 1);
    setGame(next);
    setSelected(null);
    setPromotion(null);
  };

  const startMatch = () => {
    const names: PlayerNames = {
      white: draftNames.white.trim() || 'White',
      black: draftNames.black.trim() || 'Black',
    };
    setPlayerNames(names);
    setStarted(true);
    resetMatch();
  };

  const saveMatch = () => {
    localStorage.setItem(savedGameKey, JSON.stringify({ game, playerNames }));
    pushEvent('SYSTEM', 'Game saved in this browser.');
  };

  const loadMatch = () => {
    try {
      const saved = localStorage.getItem(savedGameKey);
      if (!saved) {
        pushEvent('SYSTEM', 'No saved game was found.');
        return;
      }
      const parsed = JSON.parse(saved) as { game?: GameState; playerNames?: PlayerNames };
      if (!parsed.game || !parsed.playerNames) return;
      undoStack.current.clear();
      redoStack.current.clear();
      refreshStacks((value) => value + 1);
      setGame(parsed.game);
      setPlayerNames(parsed.playerNames);
      setStarted(true);
      setSelected(null);
      setPromotion(null);
      setGameSerial((value) => value + 1);
      pushEvent('SYSTEM', 'Saved game loaded.');
    } catch {
      pushEvent('SYSTEM', 'The saved game could not be loaded.');
    }
  };

  const exitMatch = () => {
    setDraftNames(playerNames);
    setStarted(false);
    resetMatch();
  };

  if (!started) {
    return <SetupScreen draftNames={draftNames} setDraftNames={setDraftNames} onStart={startMatch} />;
  }

  return (
    <main className="arena-shell">
      <div className="arena-grid">
        <aside className="brand-rail">
          <div className="brand-mark">
            <div className="brand-knight" aria-hidden="true">♞</div>
            <div>
              <p className="brand-name">CHESS ARENA</p>
              <p className="brand-tagline">Data Structures mini-project</p>
            </div>
          </div>
          <div className="rail-match">
            <div className="eyebrow">current match</div>
            <div className="player-rail white-player">
              <span>White</span>
              <strong>{playerNames.white}</strong>
            </div>
            <div className="player-rail black-player">
              <span>Black</span>
              <strong>{playerNames.black}</strong>
            </div>
          </div>
          <div className="rail-note">
            <strong>ACADEMIC MODE</strong>
            Every move is validated in your browser. The interface exposes the structures used for the course demo.
          </div>
        </aside>

        <section className="desk">
          <div className="desk-inner">
            <header className="desk-heading">
              <div>
                <div className="eyebrow">{game.status === 'playing' ? 'match in progress' : 'match complete'}</div>
                <h1>{game.status === 'playing' ? `${currentPlayer}'s move.` : 'The position is decided.'}</h1>
                <p className="interaction-hint">Select a piece. Legal destination squares will light up.</p>
              </div>
              <div className="turn-indicator" data-testid="status-turn">
                <span className={`turn-dot ${game.turn === 'black' ? 'black' : ''}`} />
                {game.status === 'playing' ? `${currentPlayer} to move` : 'Match complete'}
              </div>
            </header>
            <div className="board-wrap">
              <div className="board" role="grid" aria-label="Chess board" data-testid="chess-board">
                {Array.from({ length: 64 }, (_, displayIndex) => {
                  const row = Math.floor(displayIndex / 8);
                  const col = displayIndex % 8;
                  const square = orientation === 'white' ? displayIndex : 63 - displayIndex;
                  const piece = game.board[square];
                  const target = selectedTargets.get(square);
                  const isLight = (Math.floor(square / 8) + square % 8) % 2 === 0;
                  const isLast = game.lastMove?.from === square || game.lastMove?.to === square;
                  return (
                    <button
                      className={`square ${isLight ? 'light' : 'dark'} ${selected === square ? 'selected' : ''} ${isLast ? 'last-move' : ''} ${checkedKing === square ? 'check' : ''}`}
                      key={square}
                      onClick={() => handleSquare(square)}
                      role="gridcell"
                      aria-label={`${files[square % 8]}${8 - Math.floor(square / 8)}${piece ? ` ${piece.color} ${pieceLabel[piece.type]}` : ''}`}
                      data-testid={`square-${files[square % 8]}${8 - Math.floor(square / 8)}`}
                    >
                      {piece && <span className={`piece ${piece.color}`}>{glyphFor(piece)}</span>}
                      {target && <span className={target.captured || target.enPassant ? 'capture-ring' : 'move-dot'} />}
                      {col === 0 && <span className="coord rank">{orientation === 'white' ? 8 - row : row + 1}</span>}
                      {row === 7 && <span className="coord file">{orientation === 'white' ? files[col] : files[7 - col]}</span>}
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="board-caption">
              <span>{game.lastMove ? `last move · ${game.lastMove.san}` : 'opening position'}</span>
              <span>{orientation === 'white' ? 'white perspective' : 'black perspective'}</span>
            </div>
          </div>
        </section>

        <aside className="side-panel">
          <section className={`panel-card status-card ${isGameOver(game.status) ? 'game-over' : ''}`} data-testid="status-card">
            <div className="status-label">position status</div>
            <h2 className="status-title" data-testid="text-game-status">{statusHeading}</h2>
            <p className="status-copy">{statusCopy}</p>
            <div className="status-rule" />
            <div className="named-turn">
              <span>White</span><strong>{playerNames.white}</strong>
              <span>Black</span><strong>{playerNames.black}</strong>
            </div>
            <div className="mini-stat"><span>Total moves</span><strong>{game.history.length}</strong></div>
            <div className="mini-stat"><span>Captures</span><strong>{capturedPieces.length}</strong></div>
            <div className="mini-stat"><span>Checks</span><strong>{checkCount}</strong></div>
          </section>

          <section className="panel-card controls" aria-label="Game controls">
            <button className="control-btn" onClick={undo} disabled={!undoStack.current.size} data-testid="button-undo"><Undo2 size={14} /> Undo</button>
            <button className="control-btn" onClick={redo} disabled={!redoStack.current.size} data-testid="button-redo"><Redo2 size={14} /> Redo</button>
            <button className="control-btn" onClick={() => setOrientation((value) => value === 'white' ? 'black' : 'white')} data-testid="button-flip">Flip board</button>
            <button className="control-btn primary" onClick={resetMatch} data-testid="button-reset"><RotateCcw size={14} /> New game</button>
            <button className="control-btn" onClick={saveMatch}><Save size={14} /> Save game</button>
            <button className="control-btn" onClick={loadMatch}>Load game</button>
            <button className="control-btn exit-btn" onClick={exitMatch}><LogOut size={14} /> Change players</button>
          </section>

          <section className="panel-card workspace-card">
            <div className="tab-bar" role="tablist" aria-label="Game information">
              <button className={view === 'history' ? 'active' : ''} onClick={() => setView('history')}><History size={14} /> History</button>
              <button className={view === 'stats' ? 'active' : ''} onClick={() => setView('stats')}><BarChart3 size={14} /> Stats</button>
              <button className={view === 'leaderboard' ? 'active' : ''} onClick={() => setView('leaderboard')}><Trophy size={14} /> Rankings</button>
            </div>
            {view === 'history' && (
              <div className="history-pane">
                <div className="history-head">
                  <h2>Move history</h2>
                  <span className="history-count">{displayedMoveIndexes.length}/{game.history.length}</span>
                </div>
                <label className="search-box">
                  <Search size={14} />
                  <input value={moveSearch} onChange={(event) => setMoveSearch(event.target.value)} placeholder="Search SAN, e.g. e4 or Nf3" />
                </label>
                <div className="history-list" data-testid="move-history">
                  {!movePairs.length ? (
                    <div className="empty-history">No moves yet.<br />Choose a piece on the board to begin.</div>
                  ) : !displayedMoveIndexes.length ? (
                    <div className="empty-history">No matching moves found.</div>
                  ) : movePairs.map((row) => (
                    <div className={`move-row ${row.current ? 'current' : ''}`} key={row.number}>
                      <span className="move-number">{String(row.number).padStart(2, '0')}</span>
                      <span className="move-san">{row.white || '—'}</span>
                      <span className="move-san">{row.black || '—'}</span>
                    </div>
                  ))}
                </div>
                <div className="history-foot">Linked list nodes: {moveList.length} · Hash keys: {moveSearchIndex.size}</div>
              </div>
            )}
            {view === 'stats' && (
              <div className="stats-pane">
                <div className="stats-grid">
                  <div><span>Moves</span><strong>{game.history.length}</strong></div>
                  <div><span>Captures</span><strong>{capturedPieces.length}</strong></div>
                  <div><span>Checks</span><strong>{checkCount}</strong></div>
                  <div><span>Graph edges</span><strong>{movementGraph.edgeCount}</strong></div>
                </div>
                <div className="captured-block">
                  <span className="section-kicker">Captured by {playerNames.white}</span>
                  <div className="captured-row">
                    {capturedByColor('black').length
                      ? capturedByColor('black').map((piece, index) => <span key={`${piece.type}-${index}`} className="captured-piece">{glyphFor(piece)}</span>)
                      : <span>None</span>}
                  </div>
                  <span className="section-kicker">Captured by {playerNames.black}</span>
                  <div className="captured-row">
                    {capturedByColor('white').length
                      ? capturedByColor('white').map((piece, index) => <span key={`${piece.type}-${index}`} className="captured-piece">{glyphFor(piece)}</span>)
                      : <span>None</span>}
                  </div>
                </div>
                <div className="event-feed">
                  <span className="section-kicker">FIFO event queue</span>
                  {events.length ? events.slice(0, 4).map((event) => <div className="event-row" key={event.id}><b>{event.kind}</b><span>{event.message}</span></div>) : <p>No events processed yet.</p>}
                </div>
              </div>
            )}
            {view === 'leaderboard' && (
              <div className="leaderboard-pane">
                <div className="history-head">
                  <h2>Player rankings</h2>
                  <span className="history-count">BST inorder</span>
                </div>
                {leaderboardTree.length ? leaderboardTree.map((player, index) => (
                  <div className="leader-row" key={player.name}>
                    <span className="leader-rank">{index + 1}</span>
                    <strong>{player.name}</strong>
                    <span>{player.wins}W · {player.draws}D · {player.losses}L</span>
                  </div>
                )) : <div className="empty-history">Finish a game to create the first ranking entry.</div>}
              </div>
            )}
          </section>

          <section className="panel-card ds-card">
            <div className="history-head">
              <h2>Data structure lab</h2>
              <span className="history-count">LIVE</span>
            </div>
            <div className="ds-grid">
              <span><Database size={13} /> 8×8 array <b>64 squares</b></span>
              <span><ListTree size={13} /> Linked list <b>{moveList.length} nodes</b></span>
              <span><Undo2 size={13} /> Stack <b>{undoStack.current.size} undo</b></span>
              <span><GitBranch size={13} /> Graph + BFS <b>{movementGraph.breadthFirstSearch(selected ?? 0).length} visited</b></span>
            </div>
          </section>
          <div className="tips"><span>VIVA TIP</span> · Explain why the move record is a linked list and why Undo follows LIFO order.</div>
        </aside>
      </div>

      {promotion && (
        <div className="modal-backdrop" role="dialog" aria-modal="true" data-testid="promotion-dialog">
          <div className="promotion-modal">
            <div className="eyebrow">pawn reached the back rank</div>
            <h2>Choose a promotion</h2>
            <p>The move is waiting for your decision. Select the piece that completes your plan.</p>
            <div className="promotion-options">
              {promotionPieces.map((type) => {
                const move = promotion.find((candidate) => candidate.promotion === type);
                if (!move) return null;
                return (
                  <button className="promotion-option" onClick={() => commit(move)} key={type} aria-label={`Promote to ${pieceLabel[type]}`} data-testid={`promotion-${type}`}>
                    <span className={`piece ${game.turn}`}>{glyphFor({ type, color: game.turn })}</span>
                    <small>{pieceLabel[type]}</small>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

export default App;