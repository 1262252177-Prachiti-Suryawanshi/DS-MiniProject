export type Color = 'white' | 'black';
export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
export type Piece = { type: PieceType; color: Color };
export type Board = Array<Piece | null>;
export type CastlingRights = { K: boolean; Q: boolean; k: boolean; q: boolean };
export type Move = {
  from: number;
  to: number;
  piece: Piece;
  captured?: Piece;
  promotion?: PieceType;
  castle?: 'K' | 'Q' | 'k' | 'q';
  enPassant?: boolean;
};
export type MoveRecord = Move & { san: string };
export type GameStatus = 'playing' | 'checkmate' | 'stalemate' | 'draw-50' | 'draw-threefold' | 'draw-insufficient';
export type GameState = {
  board: Board;
  turn: Color;
  castling: CastlingRights;
  enPassant: number | null;
  halfmove: number;
  fullmove: number;
  history: MoveRecord[];
  positionCounts: Record<string, number>;
  lastMove: MoveRecord | null;
  status: GameStatus;
};

const backRank: PieceType[] = ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'];
const pieceGlyph: Record<PieceType, Record<Color, string>> = {
  k: { white: '♔', black: '♚' }, q: { white: '♕', black: '♛' },
  r: { white: '♖', black: '♜' }, b: { white: '♗', black: '♝' },
  n: { white: '♘', black: '♞' }, p: { white: '♙', black: '♟' },
};
export const glyphFor = (piece: Piece) => pieceGlyph[piece.type][piece.color];
export const pieceLabel: Record<PieceType, string> = { k: 'King', q: 'Queen', r: 'Rook', b: 'Bishop', n: 'Knight', p: 'Pawn' };
export const opposite = (color: Color): Color => color === 'white' ? 'black' : 'white';
export const squareName = (sq: number) => `${String.fromCharCode(97 + sq % 8)}${8 - Math.floor(sq / 8)}`;

const inside = (r: number, f: number) => r >= 0 && r < 8 && f >= 0 && f < 8;
const at = (r: number, f: number) => r * 8 + f;

export function createInitialState(): GameState {
  const board: Board = Array(64).fill(null);
  for (let f = 0; f < 8; f++) {
    board[8 + f] = { type: 'p', color: 'black' };
    board[48 + f] = { type: 'p', color: 'white' };
    board[f] = { type: backRank[f], color: 'black' };
    board[56 + f] = { type: backRank[f], color: 'white' };
  }
  const state: GameState = {
    board, turn: 'white', castling: { K: true, Q: true, k: true, q: true },
    enPassant: null, halfmove: 0, fullmove: 1, history: [], positionCounts: {}, lastMove: null, status: 'playing',
  };
  const key = positionKey(state);
  state.positionCounts[key] = 1;
  return state;
}

export function isSquareAttacked(board: Board, target: number, by: Color): boolean {
  const tr = Math.floor(target / 8), tf = target % 8;
  const pawnSourceRank = tr + (by === 'white' ? 1 : -1);
  for (const df of [-1, 1]) {
    if (inside(pawnSourceRank, tf + df)) {
      const p = board[at(pawnSourceRank, tf + df)];
      if (p?.color === by && p.type === 'p') return true;
    }
  }
  for (const [dr, df] of [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]]) {
    if (inside(tr + dr, tf + df)) {
      const p = board[at(tr + dr, tf + df)];
      if (p?.color === by && p.type === 'n') return true;
    }
  }
  for (const dr of [-1, 0, 1]) for (const df of [-1, 0, 1]) {
    if (dr || df) {
      const p = inside(tr + dr, tf + df) ? board[at(tr + dr, tf + df)] : null;
      if (p?.color === by && p.type === 'k') return true;
    }
  }
  const rays = [
    { dirs: [[-1, 0], [1, 0], [0, -1], [0, 1]], types: ['r', 'q'] },
    { dirs: [[-1, -1], [-1, 1], [1, -1], [1, 1]], types: ['b', 'q'] },
  ] as const;
  for (const ray of rays) for (const [dr, df] of ray.dirs) {
    let r = tr + dr, f = tf + df;
    while (inside(r, f)) {
      const p = board[at(r, f)];
      if (p) {
        if (p.color === by && (ray.types as readonly string[]).includes(p.type)) return true;
        break;
      }
      r += dr; f += df;
    }
  }
  return false;
}

export function findKing(board: Board, color: Color): number {
  return board.findIndex(p => p?.color === color && p.type === 'k');
}
export function inCheck(board: Board, color: Color): boolean {
  const king = findKing(board, color);
  return king >= 0 && isSquareAttacked(board, king, opposite(color));
}

function addSliding(board: Board, from: number, piece: Piece, directions: number[][], moves: Move[]) {
  const r0 = Math.floor(from / 8), f0 = from % 8;
  for (const [dr, df] of directions) {
    let r = r0 + dr, f = f0 + df;
    while (inside(r, f)) {
      const to = at(r, f), target = board[to];
      if (!target) moves.push({ from, to, piece });
      else {
        if (target.color !== piece.color && target.type !== 'k') moves.push({ from, to, piece, captured: target });
        break;
      }
      r += dr; f += df;
    }
  }
}

export function pseudoMoves(state: GameState, from: number): Move[] {
  const piece = state.board[from];
  if (!piece || piece.color !== state.turn) return [];
  const moves: Move[] = [];
  const r = Math.floor(from / 8), f = from % 8;
  if (piece.type === 'p') {
    const dir = piece.color === 'white' ? -1 : 1;
    const start = piece.color === 'white' ? 6 : 1;
    const promotionRank = piece.color === 'white' ? 0 : 7;
    const oneR = r + dir;
    if (inside(oneR, f) && !state.board[at(oneR, f)]) {
      const to = at(oneR, f);
      if (oneR === promotionRank) (['q', 'r', 'b', 'n'] as PieceType[]).forEach(promotion => moves.push({ from, to, piece, promotion }));
      else moves.push({ from, to, piece });
      if (r === start && !state.board[at(r + dir * 2, f)]) moves.push({ from, to: at(r + dir * 2, f), piece });
    }
    for (const df of [-1, 1]) {
      const nr = r + dir, nf = f + df;
      if (!inside(nr, nf)) continue;
      const to = at(nr, nf), target = state.board[to];
      if (target && target.color !== piece.color && target.type !== 'k') {
        if (nr === promotionRank) (['q', 'r', 'b', 'n'] as PieceType[]).forEach(promotion => moves.push({ from, to, piece, captured: target, promotion }));
        else moves.push({ from, to, piece, captured: target });
      } else if (to === state.enPassant) {
        const captured = state.board[at(r, nf)];
        if (captured?.type === 'p' && captured.color !== piece.color) moves.push({ from, to, piece, captured, enPassant: true });
      }
    }
  } else if (piece.type === 'n') {
    for (const [dr, df] of [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]]) {
      if (inside(r + dr, f + df)) {
        const to = at(r + dr, f + df), target = state.board[to];
        if (!target || (target.color !== piece.color && target.type !== 'k')) moves.push({ from, to, piece, captured: target || undefined });
      }
    }
  } else if (piece.type === 'b') addSliding(state.board, from, piece, [[-1, -1], [-1, 1], [1, -1], [1, 1]], moves);
  else if (piece.type === 'r') addSliding(state.board, from, piece, [[-1, 0], [1, 0], [0, -1], [0, 1]], moves);
  else if (piece.type === 'q') addSliding(state.board, from, piece, [[-1, -1], [-1, 1], [1, -1], [1, 1], [-1, 0], [1, 0], [0, -1], [0, 1]], moves);
  else if (piece.type === 'k') {
    for (const dr of [-1, 0, 1]) for (const df of [-1, 0, 1]) if (dr || df) {
      if (inside(r + dr, f + df)) {
        const to = at(r + dr, f + df), target = state.board[to];
        if (!target || (target.color !== piece.color && target.type !== 'k')) moves.push({ from, to, piece, captured: target || undefined });
      }
    }
    const enemy = opposite(piece.color);
    const home = piece.color === 'white' ? 60 : 4;
    if (from === home && !inCheck(state.board, piece.color)) {
      const kingSide = piece.color === 'white' ? state.castling.K : state.castling.k;
      const queenSide = piece.color === 'white' ? state.castling.Q : state.castling.q;
      if (kingSide && !state.board[home + 1] && !state.board[home + 2] && !isSquareAttacked(state.board, home + 1, enemy) && !isSquareAttacked(state.board, home + 2, enemy)) {
        moves.push({ from, to: home + 2, piece, castle: piece.color === 'white' ? 'K' : 'k' });
      }
      if (queenSide && !state.board[home - 1] && !state.board[home - 2] && !state.board[home - 3] && !isSquareAttacked(state.board, home - 1, enemy) && !isSquareAttacked(state.board, home - 2, enemy)) {
        moves.push({ from, to: home - 2, piece, castle: piece.color === 'white' ? 'Q' : 'q' });
      }
    }
  }
  return moves;
}

function applyBoard(board: Board, move: Move): Board {
  const next = board.slice();
  next[move.from] = null;
  if (move.enPassant) next[move.to + (move.piece.color === 'white' ? 8 : -8)] = null;
  const placed: Piece = move.promotion ? { type: move.promotion, color: move.piece.color } : move.piece;
  next[move.to] = placed;
  if (move.castle) {
    const rank = move.piece.color === 'white' ? 7 : 0;
    const rookFrom = move.castle.toLowerCase() === 'k' ? at(rank, 7) : at(rank, 0);
    const rookTo = move.castle.toLowerCase() === 'k' ? at(rank, 5) : at(rank, 3);
    next[rookTo] = next[rookFrom]; next[rookFrom] = null;
  }
  return next;
}

function updateRights(rights: CastlingRights, move: Move): CastlingRights {
  const next = { ...rights };
  if (move.piece.type === 'k') {
    if (move.piece.color === 'white') { next.K = false; next.Q = false; } else { next.k = false; next.q = false; }
  }
  if (move.piece.type === 'r' || move.captured?.type === 'r') {
    const squares: Array<[number, keyof CastlingRights]> = [[56, 'Q'], [63, 'K'], [0, 'q'], [7, 'k']];
    for (const [sq, key] of squares) if (move.from === sq || move.to === sq) next[key] = false;
  }
  return next;
}

function rawNext(state: GameState, move: Move): GameState {
  const nextTurn = opposite(state.turn);
  const next: GameState = {
    ...state,
    board: applyBoard(state.board, move),
    turn: nextTurn,
    castling: updateRights(state.castling, move),
    enPassant: move.piece.type === 'p' && Math.abs(move.to - move.from) === 16 ? (move.from + move.to) / 2 : null,
    halfmove: move.piece.type === 'p' || move.captured ? 0 : state.halfmove + 1,
    fullmove: state.fullmove + (state.turn === 'black' ? 1 : 0),
  };
  return next;
}

export function applyMove(state: GameState, move: Move): GameState {
  const legal = getLegalMoves(state, move.from).find(m => m.to === move.to && (m.promotion || undefined) === (move.promotion || undefined));
  if (!legal) return state;
  const next = rawNext(state, legal);
  const givesCheck = inCheck(next.board, next.turn);
  const replies = getAllLegalMoves(next);
  const suffix = givesCheck ? (replies.length ? '+' : '#') : '';
  let san = '';
  if (legal.castle) san = legal.castle.toLowerCase() === 'k' ? 'O-O' : 'O-O-O';
  else {
    const letter = legal.piece.type === 'p' ? '' : legal.piece.type.toUpperCase();
    const others = getAllLegalMoves(state).filter(m => m.to === legal.to && m.piece.type === legal.piece.type && m.piece.color === legal.piece.color && m.from !== legal.from);
    const disambiguation = others.length ? (others.every(m => m.from % 8 !== legal.from % 8) ? String.fromCharCode(97 + legal.from % 8) : (others.every(m => Math.floor(m.from / 8) !== Math.floor(legal.from / 8)) ? String(8 - Math.floor(legal.from / 8)) : squareName(legal.from))) : '';
    const capture = Boolean(legal.captured || legal.enPassant);
    san = `${letter}${disambiguation}${capture && legal.piece.type === 'p' ? String.fromCharCode(97 + legal.from % 8) : ''}${capture ? 'x' : ''}${squareName(legal.to)}${legal.promotion ? `=${legal.promotion.toUpperCase()}` : ''}`;
  }
  san += suffix;
  const record: MoveRecord = { ...legal, san };
  next.history = [...state.history, record];
  next.lastMove = record;
  const key = positionKey(next);
  next.positionCounts = { ...state.positionCounts, [key]: (state.positionCounts[key] || 0) + 1 };
  next.status = evaluateStatus(next);
  return next;
}

export function getLegalMoves(state: GameState, from: number): Move[] {
  return pseudoMoves(state, from).filter(move => !inCheck(applyBoard(state.board, move), state.turn));
}
export function getAllLegalMoves(state: GameState): Move[] {
  const all: Move[] = [];
  state.board.forEach((p, i) => { if (p?.color === state.turn) all.push(...getLegalMoves(state, i)); });
  return all;
}

function positionKey(state: GameState): string {
  return state.board.map(p => p ? `${p.color[0]}${p.type}` : '..').join('') + `|${state.turn}|${Object.entries(state.castling).filter(([, v]) => v).map(([k]) => k).join('') || '-'}|${state.enPassant ?? '-'}`;
}
function insufficient(board: Board): boolean {
  const pieces = board.filter(Boolean) as Piece[];
  const nonKings = pieces.filter(p => p.type !== 'k');
  if (!nonKings.length) return true;
  if (nonKings.some(p => ['p', 'q', 'r'].includes(p.type))) return false;
  if (nonKings.length === 1 && ['b', 'n'].includes(nonKings[0].type)) return true;
  if (nonKings.length === 2 && nonKings.every(p => p.type === 'b')) {
    const colors = board.map((p, i) => p?.type === 'b' ? (Math.floor(i / 8) + i % 8) % 2 : null).filter(v => v !== null);
    return colors[0] === colors[1];
  }
  return false;
}
export function evaluateStatus(state: GameState): GameStatus {
  const moves = getAllLegalMoves(state);
  if (!moves.length) return inCheck(state.board, state.turn) ? 'checkmate' : 'stalemate';
  if (insufficient(state.board)) return 'draw-insufficient';
  if (state.halfmove >= 100) return 'draw-50';
  if ((state.positionCounts[positionKey(state)] || 0) >= 3) return 'draw-threefold';
  return 'playing';
}
export function isGameOver(status: GameStatus) { return status !== 'playing'; }
export function statusLabel(status: GameStatus, turn: Color): string {
  if (status === 'checkmate') return `${turn === 'white' ? 'Black' : 'White'} wins by checkmate`;
  if (status === 'stalemate') return 'Draw by stalemate';
  if (status === 'draw-50') return 'Draw by 50-move rule';
  if (status === 'draw-threefold') return 'Draw by threefold repetition';
  if (status === 'draw-insufficient') return 'Draw by insufficient material';
  return `${turn === 'white' ? 'White' : 'Black'} to move`;
}