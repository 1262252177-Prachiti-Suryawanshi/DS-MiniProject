/**
 * Custom data structures used by the Chess Game & Move Management System.
 * These are intentionally small and readable for a Data Structures viva.
 */

type ListNode<T> = {
  value: T;
  next: ListNode<T> | null;
};

export class MoveLinkedList<T> {
  private head: ListNode<T> | null = null;
  private tail: ListNode<T> | null = null;
  private count = 0;

  get length() {
    return this.count;
  }

  append(value: T) {
    const node: ListNode<T> = { value, next: null };
    if (!this.head) this.head = node;
    else this.tail!.next = node;
    this.tail = node;
    this.count += 1;
  }

  clear() {
    this.head = null;
    this.tail = null;
    this.count = 0;
  }

  forEach(callback: (value: T, index: number) => void) {
    let current = this.head;
    let index = 0;
    while (current) {
      callback(current.value, index);
      current = current.next;
      index += 1;
    }
  }

  find(predicate: (value: T) => boolean): T | undefined {
    let current = this.head;
    while (current) {
      if (predicate(current.value)) return current.value;
      current = current.next;
    }
    return undefined;
  }

  toArray() {
    const values: T[] = [];
    this.forEach((value) => values.push(value));
    return values;
  }
}

export class Stack<T> {
  private top: ListNode<T> | null = null;
  private count = 0;

  get size() {
    return this.count;
  }

  push(value: T) {
    this.top = { value, next: this.top };
    this.count += 1;
  }

  pop(): T | undefined {
    if (!this.top) return undefined;
    const value = this.top.value;
    this.top = this.top.next;
    this.count -= 1;
    return value;
  }

  peek() {
    return this.top?.value;
  }

  clear() {
    this.top = null;
    this.count = 0;
  }
}

export class Queue<T> {
  private head: ListNode<T> | null = null;
  private tail: ListNode<T> | null = null;
  private count = 0;

  get size() {
    return this.count;
  }

  enqueue(value: T) {
    const node: ListNode<T> = { value, next: null };
    if (!this.head) this.head = node;
    else this.tail!.next = node;
    this.tail = node;
    this.count += 1;
  }

  dequeue(): T | undefined {
    if (!this.head) return undefined;
    const value = this.head.value;
    this.head = this.head.next;
    this.count -= 1;
    if (!this.head) this.tail = null;
    return value;
  }

  drain(callback: (value: T) => void) {
    let event = this.dequeue();
    while (event !== undefined) {
      callback(event);
      event = this.dequeue();
    }
  }
}

type HashEntry<T> = {
  key: string;
  value: T;
  next: HashEntry<T> | null;
};

export class HashTable<T> {
  private buckets: Array<HashEntry<T> | null>;
  private count = 0;

  constructor(bucketCount = 31) {
    this.buckets = Array.from({ length: bucketCount }, () => null);
  }

  private hash(key: string) {
    let hash = 0;
    for (let index = 0; index < key.length; index += 1) {
      hash = (hash * 31 + key.charCodeAt(index)) >>> 0;
    }
    return hash % this.buckets.length;
  }

  set(key: string, value: T) {
    const bucketIndex = this.hash(key);
    let current = this.buckets[bucketIndex];
    while (current) {
      if (current.key === key) {
        current.value = value;
        return;
      }
      current = current.next;
    }
    this.buckets[bucketIndex] = {
      key,
      value,
      next: this.buckets[bucketIndex],
    };
    this.count += 1;
  }

  get(key: string) {
    let current = this.buckets[this.hash(key)];
    while (current) {
      if (current.key === key) return current.value;
      current = current.next;
    }
    return undefined;
  }

  has(key: string) {
    return this.get(key) !== undefined;
  }

  get size() {
    return this.count;
  }
}

type TreeNode<T> = {
  key: number;
  value: T;
  left: TreeNode<T> | null;
  right: TreeNode<T> | null;
};

export class BinarySearchTree<T> {
  private root: TreeNode<T> | null = null;

  insert(key: number, value: T) {
    const node: TreeNode<T> = { key, value, left: null, right: null };
    if (!this.root) {
      this.root = node;
      return;
    }

    let current = this.root;
    while (true) {
      if (key < current.key) {
        if (current.left) current = current.left;
        else {
          current.left = node;
          return;
        }
      } else if (current.right) current = current.right;
      else {
        current.right = node;
        return;
      }
    }
  }

  inorder() {
    const values: Array<{ key: number; value: T }> = [];
    const visit = (node: TreeNode<T> | null) => {
      if (!node) return;
      visit(node.left);
      values.push({ key: node.key, value: node.value });
      visit(node.right);
    };
    visit(this.root);
    return values;
  }
}

export class MovementGraph {
  private adjacency: number[][] = Array.from({ length: 64 }, () => []);

  clear() {
    this.adjacency = Array.from({ length: 64 }, () => []);
  }

  addEdge(from: number, to: number) {
    if (!this.adjacency[from].includes(to)) this.adjacency[from].push(to);
  }

  get edgeCount() {
    return this.adjacency.reduce((total, edges) => total + edges.length, 0);
  }

  breadthFirstSearch(start: number) {
    const visited = new Set<number>();
    const order: number[] = [];
    const pending = new Queue<number>();
    pending.enqueue(start);
    visited.add(start);

    let square = pending.dequeue();
    while (square !== undefined) {
      order.push(square);
      for (const neighbor of this.adjacency[square]) {
        if (!visited.has(neighbor)) {
          visited.add(neighbor);
          pending.enqueue(neighbor);
        }
      }
      square = pending.dequeue();
    }
    return order;
  }
}
