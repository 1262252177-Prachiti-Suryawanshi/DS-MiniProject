export type PlayerStats = {
  name: string;
  games: number;
  wins: number;
  losses: number;
  draws: number;
};

const STORAGE_KEY = 'chess-arena-player-stats';

export function loadPlayerStats(): PlayerStats[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return [];
    const parsed = JSON.parse(saved) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((entry): entry is PlayerStats => (
      typeof entry === 'object' &&
      entry !== null &&
      typeof (entry as PlayerStats).name === 'string' &&
      typeof (entry as PlayerStats).games === 'number' &&
      typeof (entry as PlayerStats).wins === 'number' &&
      typeof (entry as PlayerStats).losses === 'number' &&
      typeof (entry as PlayerStats).draws === 'number'
    ));
  } catch {
    return [];
  }
}

export function savePlayerStats(stats: PlayerStats[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
}

export function recordResult(
  stats: PlayerStats[],
  white: string,
  black: string,
  winner: 'white' | 'black' | 'draw',
) {
  const next = stats.map((player) => ({ ...player }));
  const ensure = (name: string) => {
    let player = next.find((entry) => entry.name === name);
    if (!player) {
      player = { name, games: 0, wins: 0, losses: 0, draws: 0 };
      next.push(player);
    }
    return player;
  };

  const whitePlayer = ensure(white);
  const blackPlayer = ensure(black);
  whitePlayer.games += 1;
  blackPlayer.games += 1;

  if (winner === 'white') {
    whitePlayer.wins += 1;
    blackPlayer.losses += 1;
  } else if (winner === 'black') {
    blackPlayer.wins += 1;
    whitePlayer.losses += 1;
  } else {
    whitePlayer.draws += 1;
    blackPlayer.draws += 1;
  }

  savePlayerStats(next);
  return next;
}
