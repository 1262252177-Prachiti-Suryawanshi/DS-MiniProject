# Chess Arena

A browser-based, rules-complete chess board for playing local matches with clear status feedback and move history.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/chess-arena/src/App.tsx` — playable arena UI and interaction state.
- `artifacts/chess-arena/src/lib/chess.ts` — source of truth for board state, legal moves, notation, and game-end rules.
- `artifacts/chess-arena/src/lib/data-structures.ts` — custom linked list, stacks, queue, hash table, BST, and movement graph.
- `artifacts/chess-arena/src/lib/player-stats.ts` — browser-persisted player statistics and results.
- `artifacts/chess-arena/src/index.css` — arena theme, board styling, responsive layout, and interaction states.

## Architecture decisions

- Chess state is client-side because a local two-player board does not need a server round trip.
- Move generation separates pseudo-legal movement from king-safety filtering.
- Game history stores immutable prior states so undo restores castling, en passant, repetition, and draw counters correctly.
- Academic structures are implemented in a small standalone module and connected to visible features instead of being decorative examples.

## Product

- Start a fresh local chess match from the opening position.
- Select pieces to reveal legal destinations and make moves by click or tap.
- Supports captures, check, checkmate, stalemate, castling, en passant, promotion, insufficient material, 50-move draws, and threefold repetition.
- Review SAN-like move history, undo moves, and flip the board.
- Enter player names before a match, search moves, view captures and event processing, save/load a local game, and inspect a BST-sorted player leaderboard.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
